﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Log_in_system
{
    public partial class successful_login : Form
    {
        public successful_login()
        {
            InitializeComponent();
        }
    }
}
